#!/bin/bash

# This file is obsolete. MongoDB is no longer used in this project.
