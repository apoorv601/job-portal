const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const sequelize = require('./sequelize');
const User = require('./models/User');
const Job = require('./models/Job');
const Company = require('./models/Company');
const Application = require('./models/Application');

// Associations
User.hasMany(Application, { foreignKey: 'userId' });
Application.belongsTo(User, { foreignKey: 'userId' });
Job.hasMany(Application, { foreignKey: 'jobId' });
Application.belongsTo(Job, { foreignKey: 'jobId' });
Company.hasMany(Job, { foreignKey: 'companyId' });
Job.belongsTo(Company, { foreignKey: 'companyId' });

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'your_jwt_secret'; // In production, use environment variable

// Use the correct MongoDB Atlas connection string
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://apoorv601:hKXrU3n3wdiJ7lop@adage.lmpn8hb.mongodb.net/expat_job_portal?retryWrites=true&w=majority';

// Global variable to track MongoDB connection status
let mongoConnected = false;
let mongoError = null;

sequelize.authenticate()
  .then(() => {
    console.log('MariaDB Connected Successfully');
    mongoConnected = true;
    mongoError = null;
  })
  .catch(err => {
    console.error('MariaDB Connection Error:', err);
    mongoConnected = false;
    mongoError = err.message;
  });

sequelize.sync();

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use('/uploads', express.static('uploads'));

// Serve frontend files from Job_Portal root (parent of backend)
const frontendBuildPath = path.join(__dirname, '..');
const BASE_PATH = process.env.BASE_PATH || (process.env.NODE_ENV === 'production' ? '/Job_for_Expats' : '/');

if (fs.existsSync(path.join(frontendBuildPath, 'index.html'))) {
    app.use(BASE_PATH, express.static(frontendBuildPath));
    // SPA fallback: serve index.html for any non-API, non-upload route under BASE_PATH
    app.get(`${BASE_PATH}*`, (req, res, next) => {
        if (!req.path.startsWith(`${BASE_PATH}api`) && !req.path.startsWith(`${BASE_PATH}uploads`)) {
            res.sendFile(path.join(frontendBuildPath, 'index.html'));
        } else {
            next();
        }
    });
}

// Remove or comment out this route to allow frontend SPA to handle /Job_for_Expats
// app.get('/Job_for_Expats', (req, res) => {
//     res.send('Job for Expats route is working!');
// });

// DB Status endpoint - does not require authentication
app.get('/api/dbstatus', (req, res) => {
    res.json({
        connected: mongoConnected,
        error: mongoError,
        timestamp: new Date().toISOString(),
        mongoUri: MONGODB_URI.replace(/\/\/(.+?):.+?@/, '//******:******@') // Hide credentials
    });
});

// Authentication middleware
const auth = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Authentication failed' });
    }
};

// Role-based authorization middleware
const authorize = (roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'Forbidden: Insufficient permissions' });
        }
        next();
    };
};

// User registration
app.post('/api/register', async (req, res) => {
    const { username, password, role, name, email, nationality, currentLocation } = req.body;
    try {
        const existing = await User.findOne({ where: { username } });
        if (existing) {
            return res.status(400).json({ message: 'Username already exists' });
        }
        const hashed = await bcrypt.hash(password, 10);
        const user = await User.create({
            username,
            password: hashed,
            role,
            name,
            email,
            nationality,
            currentLocation
        });
        res.json({ success: true, user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// User login
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ where: { username } });
        if (!user) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
        res.json({ token, user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get user profile
app.get('/api/profile', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching profile', error: error.message });
    }
});

// Update user profile
app.put('/api/profile', auth, async (req, res) => {
    try {
        const { profile } = req.body;
        const user = await User.findByIdAndUpdate(
            req.user.userId,
            { $set: { profile } },
            { new: true }
        );
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Error updating profile', error: error.message });
    }
});

// Upload resume
app.post('/api/upload/resume', auth, upload.single('resume'), async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);
        user.profile.resume = `/uploads/${req.file.filename}`;
        await user.save();
        res.json({ url: user.profile.resume });
    } catch (error) {
        res.status(500).json({ message: 'Resume upload failed', error: error.message });
    }
});

// Upload profile photo
app.post('/api/upload/photo', auth, upload.single('photo'), async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);
        user.profile.photo = `/uploads/${req.file.filename}`;
        await user.save();
        res.json({ url: user.profile.photo });
    } catch (error) {
        res.status(500).json({ message: 'Photo upload failed', error: error.message });
    }
});

// POST /api/jobs (MariaDB/Sequelize version)
app.post('/api/jobs', async (req, res) => {
  try {
    const job = await Job.create(req.body);
    res.json({ success: true, job });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Post a job
app.post('/api/jobs', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        const jobData = {
            ...req.body,
            postedBy: req.user.userId
        };
        const job = new Job(jobData);
        await job.save();
        res.status(201).json({ message: 'Job posted successfully', jobId: job._id });
    } catch (error) {
        res.status(500).json({ message: 'Failed to post job', error: error.message });
    }
});

// Search jobs endpoint
app.get('/api/jobs/search', async (req, res) => {
    try {
        const { q: query } = req.query;
        if (!query || query.trim() === '') {
            // Return latest jobs if no query
            const jobs = await Job.find({}).sort({ postedAt: -1 }).limit(20).lean();
            return res.json(jobs);
        }
        // Use MongoDB text search with the text index we've already defined in the Job schema
        const jobs = await Job.find(
            { 
                $text: { $search: query },
                // Only include non-expired jobs
                $or: [
                    { expiryDate: { $gt: new Date() } },
                    { expiryDate: { $exists: false } }
                ]
            },
            // Add a relevance score
            { score: { $meta: "textScore" } }
        )
        .sort({ score: { $meta: "textScore" } }) // Sort by relevance
        .limit(20) // Limit to top 20 most relevant results
        .lean();
        
        // If text search doesn't find enough results, try a more flexible search
        if (jobs.length < 5) {
            const keywordJobs = await Job.find({
                $or: [
                    { title: { $regex: query, $options: 'i' } },
                    { company: { $regex: query, $options: 'i' } },
                    { industry: { $regex: query, $options: 'i' } },
                    { category: { $regex: query, $options: 'i' } },
                    { description: { $regex: query, $options: 'i' } }
                ],
                // Only include non-expired jobs
                $and: [
                    {
                        $or: [
                            { expiryDate: { $gt: new Date() } },
                            { expiryDate: { $exists: false } }
                        ]
                    }
                ]
            })
            .limit(20)
            .lean();
            
            // Combine and deduplicate results
            const combinedJobs = [...jobs];
            const existingIds = new Set(jobs.map(job => job._id.toString()));
            
            keywordJobs.forEach(job => {
                if (!existingIds.has(job._id.toString())) {
                    combinedJobs.push(job);
                    existingIds.add(job._id.toString());
                }
            });
            
            return res.json(combinedJobs);
        }
        
        res.json(jobs);
    } catch (error) {
        res.status(500).json({ message: 'Failed to search jobs', error: error.message });
    }
});

// Get jobs posted by the current user
app.get('/api/jobs/my', auth, authorize(['recruiter']), async (req, res) => {
    try {
        const jobs = await Job.find({ postedBy: req.user.userId })
            .sort({ postedAt: -1 }) // Most recent first
            .lean();
        
        res.json(jobs);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve jobs', error: error.message });
    }
});

// Get job listings with pagination and filters
app.get('/api/jobs', async (req, res) => {
    try {
        const { 
            page = 1, 
            limit = 10, 
            location, 
            type, 
            industry, 
            minSalary, 
            maxSalary,
            suitableForExpats,
            language,
            visaSponsorshipOffered,
            search
        } = req.query;

        // Build filter query
        const filter = {};
        
        if (location) filter.location = { $regex: location, $options: 'i' };
        if (type) filter.type = type;
        if (industry) filter.industry = industry;
        if (minSalary) filter['salary.min'] = { $gte: Number(minSalary) };
        if (maxSalary) filter['salary.max'] = { $lte: Number(maxSalary) };
        if (suitableForExpats === 'true') filter.suitableForExpats = true;
        if (visaSponsorshipOffered === 'true') filter.visaSponsorshipOffered = true;
        
        if (language) {
            filter.languages = {
                $elemMatch: {
                    language: language
                }
            };
        }
        
        // Text search
        if (search) {
            filter.$text = { $search: search };
        }

        // Pagination
        const startIndex = (Number(page) - 1) * Number(limit);
        
        // Get jobs with pagination
        const jobs = await Job.find(filter)
            .skip(startIndex)
            .limit(Number(limit))
            .sort({ postedAt: -1, featuredJob: -1 })
            .populate('postedBy', 'username profile.name');
            
        // Get total count
        const total = await Job.countDocuments(filter);
        
        res.json({
            jobs,
            totalPages: Math.ceil(total / Number(limit)),
            currentPage: Number(page),
            totalJobs: total
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve jobs', error: error.message });
    }
});

// Get a single job by ID
app.get('/api/jobs/:id', async (req, res) => {
    try {
        const job = await Job.findByPk(req.params.id, { include: [Company] });
        if (!job) return res.status(404).json({ message: 'Job not found' });
        res.json(job);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update a job
app.put('/api/jobs/:id', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        const job = await Job.findById(req.params.id);
        
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        
        // Check if the user is the job poster or an admin
        if (job.postedBy.toString() !== req.user.userId && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized to update this job' });
        }
        
        const updatedJob = await Job.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        
        res.json(updatedJob);
    } catch (error) {
        res.status(500).json({ message: 'Failed to update job', error: error.message });
    }
});

// Delete a job
app.delete('/api/jobs/:id', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        const job = await Job.findById(req.params.id);
        
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        
        // Check if the user is the job poster or an admin
        if (job.postedBy.toString() !== req.user.userId && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized to delete this job' });
        }
        
        await Job.findByIdAndDelete(req.params.id);
        res.json({ message: 'Job deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to delete job', error: error.message });
    }
});

// Apply for a job
app.post('/api/jobs/:id/apply', auth, authorize(['applicant']), async (req, res) => {
    try {
        const job = await Job.findById(req.params.id);
        
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        
        // Check if already applied
        const alreadyApplied = job.applicants.some(
            applicant => applicant.userId.toString() === req.user.userId
        );
        
        if (alreadyApplied) {
            return res.status(400).json({ message: 'You have already applied for this job' });
        }
        
        // Add applicant to the job
        job.applicants.push({
            userId: req.user.userId,
            status: 'Applied',
            appliedAt: new Date()
        });
        // Also add job to user's appliedJobs array
        await User.findByIdAndUpdate(
            req.user.userId,
            { $addToSet: { appliedJobs: job._id } }
        );
        // Create an Application document for history
        await Application.create({
            applicantId: req.user.userId,
            jobId: job._id,
            jobTitle: job.title,
            status: 'Submitted',
            coverLetter: req.body.coverLetter || '',
            applicantName: req.body.applicantName || '',
            applicantEmail: req.body.applicantEmail || ''
        });
        await job.save();
        res.json({ message: 'Application submitted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to apply for job', error: error.message });
    }
});

// POST /api/applications (MariaDB/Sequelize version)
app.post('/api/applications', async (req, res) => {
  try {
    const application = await Application.create(req.body);
    res.json({ success: true, application });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get company by ID
app.get('/api/companies/:id', async (req, res) => {
    try {
        const company = await Company.findById(req.params.id);
        if (!company) {
            return res.status(404).json({ message: 'Company not found' });
        }
        res.json(company);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve company', error: error.message });
    }
});

// Create or update company
app.post('/api/companies', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        let company = await Company.findOne({ recruiterId: req.user.userId });
        
        if (company) {
            // Update existing company
            company = await Company.findByIdAndUpdate(
                company._id,
                { ...req.body, recruiterId: req.user.userId },
                { new: true }
            );
        } else {
            // Create new company
            company = new Company({
                ...req.body,
                recruiterId: req.user.userId
            });
            await company.save();
        }
        
        res.json(company);
    } catch (error) {
        res.status(500).json({ message: 'Failed to create/update company', error: error.message });
    }
});

// Upload company logo
app.post('/api/companies/logo', auth, authorize(['recruiter', 'admin']), upload.single('logo'), async (req, res) => {
    try {
        let company = await Company.findOne({ recruiterId: req.user.userId });
        
        if (!company) {
            return res.status(404).json({ message: 'Company not found' });
        }
        
        company.logo = `/uploads/${req.file.filename}`;
        await company.save();
        res.json({ url: company.logo });
    } catch (error) {
        res.status(500).json({ message: 'Logo upload failed', error: error.message });
    }
});

// Get all applications for recruiter
app.get('/api/applications', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        // Find all jobs posted by this recruiter
        const jobs = await Job.find({ postedBy: req.user.userId })
            .populate('applicants.userId', 'username profile.name profile.email profile.resume');
            
        // Extract applications from all jobs
        const applications = jobs.flatMap(job => 
            job.applicants.map(applicant => ({
                jobId: job._id,
                jobTitle: job.title,
                applicant: applicant.userId,
                status: applicant.status,
                appliedAt: applicant.appliedAt
            }))
        );
        
        res.json(applications);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve applications', error: error.message });
    }
});

// Get current user's applications
app.get('/api/applications/my', auth, async (req, res) => {
    try {
        // Find all applications for the current user
        const applications = await Application.find({ applicantId: req.user.userId })
            .sort({ createdAt: -1 }) // Most recent first
            .lean(); // Convert Mongoose docs to plain objects for faster serialization
        
        res.json(applications);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve applications', error: error.message });
    }
});

// Update application status
app.put('/api/jobs/:jobId/applications/:userId', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        const { status } = req.body;
        const { jobId, userId } = req.params;
        
        const job = await Job.findById(jobId);
        
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        
        // Check if the user is the job poster
        if (job.postedBy.toString() !== req.user.userId && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized to update this application' });
        }
        
        // Find and update the applicant status
        const applicant = job.applicants.find(a => a.userId.toString() === userId);
        
        if (!applicant) {
            return res.status(404).json({ message: 'Application not found' });
        }
        
        applicant.status = status;
        await job.save();
        
        res.json({ message: 'Application status updated' });
    } catch (error) {
        res.status(500).json({ message: 'Failed to update application', error: error.message });
    }
});

// Get user details by ID (for recruiters to view applicants)
app.get('/api/users/:id', auth, authorize(['recruiter', 'admin']), async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select('-password');
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Failed to load user details', error: error.message });
    }
});

// Moving this endpoints to be defined before the `/api/jobs/:id` endpoint to avoid path conflicts

// Get applicants for a specific job
app.get('/api/jobs/:id/applicants', auth, authorize(['recruiter']), async (req, res) => {
    try {
        const job = await Job.findById(req.params.id);
        
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }
        
        // Verify that the job belongs to the current recruiter
        if (job.postedBy.toString() !== req.user.userId) {
            return res.status(403).json({ message: 'Not authorized to view applicants for this job' });
        }
        
        res.json(job.applicants);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve applicants', error: error.message });
    }
});

// Get applications by applicantId and jobId
app.get('/api/applications/query', auth, authorize(['recruiter']), async (req, res) => {
    try {
        const { applicantId, jobId } = req.query;
        
        if (!applicantId || !jobId) {
            return res.status(400).json({ message: 'Both applicantId and jobId are required' });
        }
        
        // Find the job to verify ownership
        const job = await Job.findById(jobId);
        if (!job || job.postedBy.toString() !== req.user.userId) {
            return res.status(403).json({ message: 'Not authorized to access this application' });
        }
        
        const applications = await Application.find({
            applicantId,
            jobId
        }).lean();
        
        res.json(applications);
    } catch (error) {
        res.status(500).json({ message: 'Failed to retrieve application', error: error.message });
    }
});

// Update application status by ID
app.put('/api/applications/:id/status', auth, authorize(['recruiter']), async (req, res) => {
    try {
        const { status } = req.body;
        const validStatuses = ['Submitted', 'Under Review', 'Shortlisted', 'Rejected', 'Offered'];
        
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ message: 'Invalid status value' });
        }
        
        const application = await Application.findById(req.params.id);
        
        if (!application) {
            return res.status(404).json({ message: 'Application not found' });
        }
        
        // Verify the job belongs to the recruiter
        const job = await Job.findById(application.jobId);
        if (!job || job.postedBy.toString() !== req.user.userId) {
            return res.status(403).json({ message: 'Not authorized to update this application' });
        }
        
        // Update the application status
        application.status = status;
        await application.save();
        
        // Also update the status in the job's applicants array
        await Job.findOneAndUpdate(
            { 
                _id: application.jobId, 
                'applicants.userId': application.applicantId 
            },
            {
                $set: { 'applicants.$.status': status }
            }
        );
        
        res.json({ message: 'Application status updated', application });
    } catch (error) {
        res.status(500).json({ message: 'Failed to update application status', error: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
